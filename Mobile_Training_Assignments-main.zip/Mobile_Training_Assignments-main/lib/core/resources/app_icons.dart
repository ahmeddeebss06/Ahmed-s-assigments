class AppIcons {
  AppIcons._();

  static const String _path = 'assets/icons/';

  static const String logo = '${_path}app_logo.png';
  static const String onboarding1 = '${_path}onboarding_1.png';
  static const String onboarding2 = '${_path}onboarding_2.png';
  static const String onboarding3 = '${_path}onboarding_3.png';
}

